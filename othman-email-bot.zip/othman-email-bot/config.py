import os

# ========================================
# إعدادات البوت - Othman Email Bot
# ========================================

BOT_TOKEN = os.environ.get("BOT_TOKEN", "9217496869:AAHQOkxMhxAKkYD5xfbf54bo_S6VF5PyfLw")

GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID", "432632814219-g2v1pi8ij5rs17gsnt1r6o0ii13lp8bc.apps.googleusercontent.com")
GOOGLE_CLIENT_SECRET = os.environ.get("GOOGLE_CLIENT_SECRET", "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")

# Railway يوفر رابط تلقائي - سيتم تحديثه بعد النشر
REDIRECT_URI = os.environ.get("REDIRECT_URI", "https://your-app.railway.app/callback")

FLASK_HOST = "0.0.0.0"
FLASK_PORT = int(os.environ.get("PORT", 5000))

SERVICE_ACCOUNT_PATH = "serviceAccount.json"

FIREBASE_CONFIG = {
    "apiKey": "AIzaSyAIQqlK_z4CPH0pqfNQN6R9r2gsBoAW1yI",
    "authDomain": "othman-email-bot.firebaseapp.com",
    "projectId": "othman-email-bot",
    "storageBucket": "othman-email-bot.firebasestorage.app",
    "messagingSenderId": "565554275759",
    "appId": "1:565554275759:web:f942ec1334fb24963a3b5a",
}

SCOPES = [
    "https://www.googleapis.com/auth/gmail.send",
    "https://www.googleapis.com/auth/userinfo.email",
    "openid"
]
