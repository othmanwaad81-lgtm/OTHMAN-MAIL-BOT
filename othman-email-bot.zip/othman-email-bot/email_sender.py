import asyncio
import base64
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from google.auth.transport.requests import Request
from firebase_manager import get_user, set_sending_status, update_user

logger = logging.getLogger(__name__)


def get_gmail_service(user_data: dict):
    """إنشاء Gmail API service من بيانات المستخدم"""
    creds = Credentials(
        token=user_data.get("access_token"),
        refresh_token=user_data.get("refresh_token"),
        token_uri=user_data.get("token_uri", "https://oauth2.googleapis.com/token"),
        client_id=user_data.get("client_id"),
        client_secret=user_data.get("client_secret"),
        scopes=user_data.get("scopes", ["https://www.googleapis.com/auth/gmail.send"])
    )

    # تجديد التوكن إذا انتهت صلاحيته
    if creds.expired and creds.refresh_token:
        creds.refresh(Request())
        update_user(int(user_data["telegram_id"]), {"access_token": creds.token})

    return build("gmail", "v1", credentials=creds)


def send_single_email(service, sender_email: str, recipient: str, subject: str, message_text: str) -> bool:
    """إرسال إيميل واحد عبر Gmail API"""
    try:
        msg = MIMEMultipart()
        msg["From"] = sender_email
        msg["To"] = recipient
        msg["Subject"] = subject
        msg.attach(MIMEText(message_text, "plain", "utf-8"))

        raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
        service.users().messages().send(userId="me", body={"raw": raw}).execute()
        return True
    except Exception as e:
        logger.error(f"خطأ في الإرسال إلى {recipient}: {e}")
        return False


async def start_sending_campaign(telegram_id: int, bot, chat_id: int):
    """بدء حملة الإرسال"""
    user = get_user(telegram_id)
    if not user:
        await bot.send_message(chat_id=chat_id, text="❌ يرجى تسجيل الدخول أولاً.")
        return

    email = user.get("email")
    recipients = user.get("recipients", [])
    subject = user.get("subject", "")
    message = user.get("message", "")

    if not all([email, recipients, subject, message]):
        missing = []
        if not recipients: missing.append("إيميلات المستلمين")
        if not subject: missing.append("موضوع الرسالة")
        if not message: missing.append("نص الرسالة")
        await bot.send_message(
            chat_id=chat_id,
            text=f"❌ البيانات غير مكتملة:\n" + "\n".join(f"• {m}" for m in missing)
        )
        return

    try:
        service = get_gmail_service(user)
    except Exception as e:
        await bot.send_message(chat_id=chat_id, text=f"❌ خطأ في الاتصال بـ Gmail: {e}")
        return

    set_sending_status(telegram_id, True)
    await bot.send_message(chat_id=chat_id, text=f"🚀 بدأ الإرسال إلى *{len(recipients)}* إيميل...", parse_mode="Markdown")

    success_count = 0
    fail_count = 0

    for i, recipient in enumerate(recipients, 1):
        # التحقق من حالة الإرسال
        user_data = get_user(telegram_id)
        if not user_data or not user_data.get("sending", False):
            await bot.send_message(chat_id=chat_id, text=f"⏹ تم إيقاف الإرسال.\n✅ أُرسل: {success_count} | ❌ فشل: {fail_count}")
            return

        success = send_single_email(service, email, recipient, subject, message)
        if success:
            success_count += 1
        else:
            fail_count += 1

        # تقرير كل 10 إيميلات
        if i % 10 == 0:
            await bot.send_message(
                chat_id=chat_id,
                text=f"📊 التقدم: {i}/{len(recipients)}\n✅ نجح: {success_count} | ❌ فشل: {fail_count}"
            )

        await asyncio.sleep(1.5)

    set_sending_status(telegram_id, False)
    await bot.send_message(
        chat_id=chat_id,
        text=f"🎉 *انتهى الإرسال!*\n\n✅ نجح: *{success_count}*\n❌ فشل: *{fail_count}*\n📧 المجموع: {len(recipients)}",
        parse_mode="Markdown"
    )
