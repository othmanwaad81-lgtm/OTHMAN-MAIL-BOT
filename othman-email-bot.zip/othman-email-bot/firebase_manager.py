import firebase_admin
from firebase_admin import credentials, firestore
from config import SERVICE_ACCOUNT_PATH

cred = credentials.Certificate(SERVICE_ACCOUNT_PATH)
firebase_admin.initialize_app(cred)
db = firestore.client()


def get_user(telegram_id: int) -> dict | None:
    doc = db.collection("users").document(str(telegram_id)).get()
    return doc.to_dict() if doc.exists else None


def save_user(telegram_id: int, data: dict):
    db.collection("users").document(str(telegram_id)).set(data, merge=True)


def update_user(telegram_id: int, fields: dict):
    db.collection("users").document(str(telegram_id)).update(fields)


def delete_user(telegram_id: int):
    db.collection("users").document(str(telegram_id)).delete()


def is_logged_in(telegram_id: int) -> bool:
    user = get_user(telegram_id)
    return user is not None and user.get("email") is not None


def set_sending_status(telegram_id: int, status: bool):
    update_user(telegram_id, {"sending": status})
