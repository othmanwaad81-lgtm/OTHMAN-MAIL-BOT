# 📧 Othman Email Bot

بوت تيليجرام لإرسال إيميلات جماعية عبر Gmail OAuth.

---

## 🚀 النشر على Railway

### الخطوة 1: رفع الملفات على GitHub
1. أنشئ مستودع جديد على GitHub
2. ارفع جميع الملفات

### الخطوة 2: ربط Railway
1. اذهب إلى [railway.app](https://railway.app)
2. New Project → Deploy from GitHub
3. اختر المستودع

### الخطوة 3: إضافة Variables
في Railway → Variables أضف:
```
BOT_TOKEN=...
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
REDIRECT_URI=https://YOUR-APP.railway.app/callback
```

### الخطوة 4: تحديث REDIRECT_URI
بعد النشر ستحصل على رابط مثل:
`https://othman-email-bot-production.railway.app`

1. انسخ الرابط
2. أضف `/callback` في النهاية
3. ضعه في Railway Variables → REDIRECT_URI
4. أضفه في Google Cloud Console → OAuth → Authorized redirect URIs

---

## 📋 طريقة الاستخدام

1. `/start` → اضغط "تسجيل الدخول بـ Google"
2. سجّل دخول بحساب Gmail
3. أضف إيميلات المستلمين
4. حدد الموضوع والرسالة
5. اضغط "بدء الإرسال" 🚀
