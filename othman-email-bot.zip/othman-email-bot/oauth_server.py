"""
Flask server للتعامل مع Google OAuth callback
يعمل بجانب بوت التيليجرام
"""
import threading
from flask import Flask, request
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build
from config import GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, REDIRECT_URI, SCOPES, FLASK_HOST, FLASK_PORT
from firebase_manager import save_user
import logging

logger = logging.getLogger(__name__)
app = Flask(__name__)

# تخزين مؤقت: state → telegram_id
pending_logins: dict[str, int] = {}

# bot instance للإرسال بعد تسجيل الدخول
_bot_instance = None
_loop = None


def set_bot(bot, loop):
    global _bot_instance, _loop
    _bot_instance = bot
    _loop = loop


def create_oauth_url(telegram_id: int) -> str:
    """إنشاء رابط OAuth للمستخدم"""
    flow = Flow.from_client_config(
        {
            "web": {
                "client_id": GOOGLE_CLIENT_ID,
                "client_secret": GOOGLE_CLIENT_SECRET,
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "redirect_uris": [REDIRECT_URI],
            }
        },
        scopes=SCOPES,
        redirect_uri=REDIRECT_URI
    )
    auth_url, state = flow.authorization_url(
        access_type="offline",
        prompt="consent"
    )
    pending_logins[state] = telegram_id
    return auth_url


@app.route("/callback")
def callback():
    state = request.args.get("state")
    code = request.args.get("code")

    if not state or state not in pending_logins:
        return "<h2>❌ رابط غير صالح أو منتهي الصلاحية.</h2>", 400

    telegram_id = pending_logins.pop(state)

    try:
        flow = Flow.from_client_config(
            {
                "web": {
                    "client_id": GOOGLE_CLIENT_ID,
                    "client_secret": GOOGLE_CLIENT_SECRET,
                    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                    "token_uri": "https://oauth2.googleapis.com/token",
                    "redirect_uris": [REDIRECT_URI],
                }
            },
            scopes=SCOPES,
            redirect_uri=REDIRECT_URI,
            state=state
        )
        flow.fetch_token(code=code)
        credentials = flow.credentials

        # جلب بيانات المستخدم
        service = build("oauth2", "v2", credentials=credentials)
        user_info = service.userinfo().get().execute()
        email = user_info.get("email")
        name = user_info.get("name", "")

        # حفظ في Firebase
        save_user(telegram_id, {
            "telegram_id": telegram_id,
            "email": email,
            "name": name,
            "access_token": credentials.token,
            "refresh_token": credentials.refresh_token,
            "token_uri": credentials.token_uri,
            "client_id": credentials.client_id,
            "client_secret": credentials.client_secret,
            "scopes": list(credentials.scopes) if credentials.scopes else SCOPES,
            "recipients": [],
            "subject": "",
            "message": "",
            "sending": False,
        })

        # إرسال رسالة للمستخدم في تيليجرام
        if _bot_instance and _loop:
            import asyncio
            asyncio.run_coroutine_threadsafe(
                notify_user(telegram_id, email),
                _loop
            )

        return """
        <html>
        <head>
            <meta charset="UTF-8">
            <style>
                body { font-family: Arial; text-align: center; padding: 50px; background: #f0f8ff; }
                .box { background: white; padding: 40px; border-radius: 15px; display: inline-block; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
                h2 { color: #25a244; }
                p { color: #555; }
            </style>
        </head>
        <body>
            <div class="box">
                <h2>✅ تم تسجيل الدخول بنجاح!</h2>
                <p>يمكنك العودة إلى تيليجرام الآن.</p>
                <p>🤖 البوت جاهز للاستخدام!</p>
            </div>
        </body>
        </html>
        """

    except Exception as e:
        logger.error(f"OAuth error: {e}")
        return f"<h2>❌ حدث خطأ: {e}</h2>", 500


async def notify_user(telegram_id: int, email: str):
    """إرسال إشعار للمستخدم بعد تسجيل الدخول"""
    try:
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        keyboard = [[InlineKeyboardButton("🏠 القائمة الرئيسية", callback_data="main_menu")]]
        await _bot_instance.send_message(
            chat_id=telegram_id,
            text=f"✅ *تم تسجيل الدخول بنجاح!*\n\n📧 الإيميل: `{email}`\n\nالبوت جاهز! 🚀",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    except Exception as e:
        logger.error(f"خطأ في الإشعار: {e}")


def run_flask():
    """تشغيل Flask في thread منفصل"""
    app.run(host=FLASK_HOST, port=FLASK_PORT, debug=False, use_reloader=False)


def start_oauth_server():
    t = threading.Thread(target=run_flask, daemon=True)
    t.start()
    logger.info(f"✅ OAuth Server يعمل على port {FLASK_PORT}")
