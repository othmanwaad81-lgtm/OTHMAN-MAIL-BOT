import asyncio
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    CallbackQueryHandler, ContextTypes, ConversationHandler, filters
)
from firebase_manager import (
    get_user, update_user, delete_user,
    is_logged_in, set_sending_status
)
from email_sender import start_sending_campaign
from oauth_server import create_oauth_url, set_bot, start_oauth_server
from config import BOT_TOKEN

logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)

# حالات المحادثة
(
    WAITING_RECIPIENTS_CHOICE,
    WAITING_RECIPIENTS_BULK,
    WAITING_RECIPIENTS_ONE,
    WAITING_SUBJECT,
    WAITING_MESSAGE,
) = range(5)


# ========== /start ==========
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    telegram_id = update.effective_user.id
    if is_logged_in(telegram_id):
        await show_main_menu(update, context)
    else:
        auth_url = create_oauth_url(telegram_id)
        keyboard = [[InlineKeyboardButton("🔐 تسجيل الدخول بـ Google", url=auth_url)]]
        await update.message.reply_text(
            "👋 مرحباً بك في *Othman Email Bot!*\n\n"
            "📧 بوت إرسال إيميلات جماعية بسهولة تامة.\n\n"
            "اضغط الزر أدناه لتسجيل الدخول بحساب Gmail الخاص بك:",
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )


# ========== القائمة الرئيسية ==========
async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    telegram_id = update.effective_user.id
    user = get_user(telegram_id)
    if not user:
        await start(update, context)
        return

    is_sending = user.get("sending", False)
    recipients_count = len(user.get("recipients", []))
    subject = user.get("subject") or "غير محدد"
    email = user.get("email", "غير محدد")

    send_btn = ("⏹ إيقاف الإرسال", "stop_sending") if is_sending else ("🚀 بدء الإرسال", "start_sending")

    keyboard = [
        [InlineKeyboardButton("📧 إضافة إيميلات المستلمين", callback_data="add_recipients")],
        [InlineKeyboardButton("✉️ تحديد الموضوع والرسالة", callback_data="set_message")],
        [InlineKeyboardButton(send_btn[0], callback_data=send_btn[1])],
        [
            InlineKeyboardButton("📊 عرض البيانات", callback_data="show_data"),
            InlineKeyboardButton("🗑 مسح الإيميلات", callback_data="clear_recipients"),
        ],
        [InlineKeyboardButton("🚪 تسجيل الخروج", callback_data="logout")],
    ]

    text = (
        f"🏠 *القائمة الرئيسية*\n\n"
        f"📧 حسابك: `{email}`\n"
        f"👥 المستلمون: *{recipients_count}* إيميل\n"
        f"📌 الموضوع: {subject}\n"
        f"📡 الإرسال: {'🟢 يعمل الآن' if is_sending else '🔴 متوقف'}"
    )

    markup = InlineKeyboardMarkup(keyboard)
    if update.callback_query:
        await update.callback_query.edit_message_text(text, parse_mode="Markdown", reply_markup=markup)
    else:
        await update.message.reply_text(text, parse_mode="Markdown", reply_markup=markup)


# ========== إضافة المستلمين ==========
async def add_recipients_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    keyboard = [
        [InlineKeyboardButton("📋 إضافة دفعة (عدة إيميلات)", callback_data="bulk_add")],
        [InlineKeyboardButton("➕ إضافة إيميل واحد", callback_data="single_add")],
        [InlineKeyboardButton("🔙 رجوع", callback_data="main_menu")],
    ]
    await query.edit_message_text(
        "📧 *إضافة المستلمين*\n\nاختر طريقة الإضافة:",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    return WAITING_RECIPIENTS_CHOICE


async def bulk_add_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        "📋 *إضافة دفعة من الإيميلات*\n\n"
        "أرسل الإيميلات مفصولة بسطر جديد أو فاصلة:\n\n"
        "مثال:\n"
        "`a@gmail.com\nb@gmail.com\nc@yahoo.com`",
        parse_mode="Markdown"
    )
    return WAITING_RECIPIENTS_BULK


async def single_add_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        "➕ *إضافة إيميل واحد*\n\nأرسل الإيميل:",
        parse_mode="Markdown"
    )
    return WAITING_RECIPIENTS_ONE


async def receive_bulk_recipients(update: Update, context: ContextTypes.DEFAULT_TYPE):
    telegram_id = update.effective_user.id
    text = update.message.text.strip()
    emails = [e.strip() for e in text.replace(",", "\n").split("\n") if e.strip()]
    valid = [e for e in emails if "@" in e and "." in e]

    if not valid:
        await update.message.reply_text("❌ لم يتم العثور على إيميلات صحيحة. حاول مجدداً.")
        return WAITING_RECIPIENTS_BULK

    user = get_user(telegram_id)
    existing = user.get("recipients", []) if user else []
    new_list = list(set(existing + valid))
    update_user(telegram_id, {"recipients": new_list})

    await update.message.reply_text(
        f"✅ تم إضافة *{len(valid)}* إيميل\n📊 المجموع الكلي: *{len(new_list)}* إيميل",
        parse_mode="Markdown"
    )
    await show_main_menu(update, context)
    return ConversationHandler.END


async def receive_single_recipient(update: Update, context: ContextTypes.DEFAULT_TYPE):
    telegram_id = update.effective_user.id
    email = update.message.text.strip()

    if "@" not in email or "." not in email:
        await update.message.reply_text("❌ إيميل غير صحيح. حاول مجدداً.")
        return WAITING_RECIPIENTS_ONE

    user = get_user(telegram_id)
    existing = user.get("recipients", []) if user else []
    if email not in existing:
        existing.append(email)
        update_user(telegram_id, {"recipients": existing})

    await update.message.reply_text(
        f"✅ تم إضافة: `{email}`\n📊 المجموع: *{len(existing)}* إيميل",
        parse_mode="Markdown"
    )
    await show_main_menu(update, context)
    return ConversationHandler.END


# ========== تحديد الرسالة ==========
async def set_message_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        "✉️ *تحديد الرسالة*\n\nأرسل *موضوع الرسالة* (Subject):",
        parse_mode="Markdown"
    )
    return WAITING_SUBJECT


async def receive_subject(update: Update, context: ContextTypes.DEFAULT_TYPE):
    subject = update.message.text.strip()
    context.user_data["temp_subject"] = subject
    await update.message.reply_text(
        f"✅ الموضوع: *{subject}*\n\nالآن أرسل *نص الرسالة*:",
        parse_mode="Markdown"
    )
    return WAITING_MESSAGE


async def receive_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    telegram_id = update.effective_user.id
    message = update.message.text.strip()
    subject = context.user_data.get("temp_subject", "")
    update_user(telegram_id, {"subject": subject, "message": message})

    await update.message.reply_text(
        f"✅ *تم حفظ الرسالة!*\n\n📌 الموضوع: *{subject}*\n📝 الرسالة:\n{message[:100]}{'...' if len(message) > 100 else ''}",
        parse_mode="Markdown"
    )
    await show_main_menu(update, context)
    return ConversationHandler.END


# ========== الإرسال ==========
async def start_sending_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    telegram_id = update.effective_user.id
    chat_id = query.message.chat_id
    await query.edit_message_text("⏳ جاري بدء الإرسال...")
    asyncio.create_task(start_sending_campaign(telegram_id, context.bot, chat_id))


async def stop_sending_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    set_sending_status(update.effective_user.id, False)
    await query.edit_message_text("⏹ *جاري إيقاف الإرسال...*", parse_mode="Markdown")
    await asyncio.sleep(2)
    await show_main_menu(update, context)


# ========== عرض البيانات ==========
async def show_data_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = get_user(update.effective_user.id)
    if not user:
        return

    recipients = user.get("recipients", [])
    r_text = "\n".join(f"• {r}" for r in recipients[:10])
    if len(recipients) > 10:
        r_text += f"\n... و {len(recipients) - 10} إيميل آخر"

    keyboard = [[InlineKeyboardButton("🔙 رجوع", callback_data="main_menu")]]
    await query.edit_message_text(
        f"📊 *بياناتك*\n\n"
        f"📧 الإيميل: `{user.get('email', '-')}`\n"
        f"📌 الموضوع: {user.get('subject') or '-'}\n"
        f"📝 الرسالة: {str(user.get('message', ''))[:60]}{'...' if len(str(user.get('message', ''))) > 60 else ''}\n\n"
        f"👥 *المستلمون ({len(recipients)}):*\n{r_text if r_text else 'لا يوجد'}",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )


# ========== مسح الإيميلات ==========
async def clear_recipients_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer("✅ تم مسح جميع الإيميلات!", show_alert=True)
    update_user(update.effective_user.id, {"recipients": []})
    await show_main_menu(update, context)


# ========== تسجيل الخروج ==========
async def logout_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    delete_user(update.effective_user.id)
    keyboard = [[InlineKeyboardButton("🔐 تسجيل الدخول مجدداً", callback_data="restart")]]
    await query.edit_message_text(
        "👋 *تم تسجيل الخروج بنجاح!*",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    return ConversationHandler.END


async def restart_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    telegram_id = update.effective_user.id
    auth_url = create_oauth_url(telegram_id)
    keyboard = [[InlineKeyboardButton("🔐 تسجيل الدخول بـ Google", url=auth_url)]]
    await query.edit_message_text(
        "اضغط الزر لتسجيل الدخول:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )


async def main_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_main_menu(update, context)
    return ConversationHandler.END


# ========== تشغيل البوت ==========
def main():
    app = Application.builder().token(BOT_TOKEN).build()

    # تشغيل OAuth Server
    start_oauth_server()

    conv_handler = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(add_recipients_callback, pattern="^add_recipients$"),
            CallbackQueryHandler(set_message_callback, pattern="^set_message$"),
        ],
        states={
            WAITING_RECIPIENTS_CHOICE: [
                CallbackQueryHandler(bulk_add_callback, pattern="^bulk_add$"),
                CallbackQueryHandler(single_add_callback, pattern="^single_add$"),
                CallbackQueryHandler(main_menu_callback, pattern="^main_menu$"),
            ],
            WAITING_RECIPIENTS_BULK: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_bulk_recipients)],
            WAITING_RECIPIENTS_ONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_single_recipient)],
            WAITING_SUBJECT: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_subject)],
            WAITING_MESSAGE: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_message)],
        },
        fallbacks=[
            CommandHandler("start", start),
            CallbackQueryHandler(main_menu_callback, pattern="^main_menu$"),
        ],
        per_message=False
    )

    app.add_handler(CommandHandler("start", start))
    app.add_handler(conv_handler)
    app.add_handler(CallbackQueryHandler(start_sending_callback, pattern="^start_sending$"))
    app.add_handler(CallbackQueryHandler(stop_sending_callback, pattern="^stop_sending$"))
    app.add_handler(CallbackQueryHandler(show_data_callback, pattern="^show_data$"))
    app.add_handler(CallbackQueryHandler(clear_recipients_callback, pattern="^clear_recipients$"))
    app.add_handler(CallbackQueryHandler(logout_callback, pattern="^logout$"))
    app.add_handler(CallbackQueryHandler(restart_callback, pattern="^restart$"))
    app.add_handler(CallbackQueryHandler(main_menu_callback, pattern="^main_menu$"))

    # ربط البوت بـ OAuth server
    async def post_init(application):
        import asyncio
        set_bot(application.bot, asyncio.get_event_loop())

    app.post_init = post_init

    logger.info("✅ البوت يعمل...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
